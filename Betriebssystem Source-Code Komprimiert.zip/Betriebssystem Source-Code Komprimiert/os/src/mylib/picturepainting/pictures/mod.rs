pub mod blinking;
pub mod charmander;
pub mod crumpy_cat;
pub mod cute_cat;
pub mod doge;
pub mod ghost;
