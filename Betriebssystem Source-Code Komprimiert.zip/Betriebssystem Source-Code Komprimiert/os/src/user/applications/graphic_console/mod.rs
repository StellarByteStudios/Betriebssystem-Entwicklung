// Funktioniert nicht mehr wegen neuer Threads
//pub mod gc_programms;
pub mod graphic_console_logic;
pub mod graphic_console_printer;
