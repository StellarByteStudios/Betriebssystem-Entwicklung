#[macro_use]
pub mod multiboot;
