// System-Aufrufe nachfolgend
pub mod sys_getlastkey;
pub mod sys_gettid;
pub mod sys_hello_world;
pub mod sys_hello_world_print;
pub mod sys_read;
pub mod sys_write;
