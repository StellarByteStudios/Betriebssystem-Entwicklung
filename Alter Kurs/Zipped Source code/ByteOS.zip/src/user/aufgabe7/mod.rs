pub mod bmp_hhu;
pub mod calculate_newton_fractals;
pub mod draw_mandelbrot;
pub mod graphic_demo;
pub mod test_console;
