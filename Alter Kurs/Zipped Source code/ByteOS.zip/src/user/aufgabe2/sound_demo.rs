use crate::devices::pcspk;

pub fn run() {

    /* Hier muss Code eingefuegt werden */
}
