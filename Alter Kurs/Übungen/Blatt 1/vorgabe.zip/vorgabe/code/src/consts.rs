#![allow(dead_code)]          // avoid warnings 

// Stack size for each new thread
pub const STACK_SIZE: usize = 0x4000;
