

use crate::devices::cga;        // shortcut for cga
use crate::devices::cga_print;  // used to import code needed by println! 


pub fn run () {

   /* Hier muss Code eingefuegt werden */

}
